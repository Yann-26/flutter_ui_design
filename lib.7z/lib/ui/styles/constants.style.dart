// ignore_for_file: constant_identifier_names

import 'package:flutter/animation.dart';

const BUTTON_MIN_SIZE = Size(150, 45);
const BUTTON_MAX_SIZE = Size(300, 45);

